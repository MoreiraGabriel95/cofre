public class Real extends Moeda {
    // construtor da classe
    public Real(double valor, String pais) {
        super(valor, pais);
    }

    // método toString() para retornar uma representação em String da moeda
    @Override
    public String toString() {
        return "Moeda de " + this.getPais() + ", valor R$ " + this.getValor();
    }
}
