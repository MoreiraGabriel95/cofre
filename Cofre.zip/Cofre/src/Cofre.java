import java.util.ArrayList;
import java.util.List;

public class Cofre {
    private List<Moeda> moedas;

    public Cofre() {
        this.moedas = new ArrayList<>();
    }

    public void adicionarMoeda(Moeda moeda) {
        this.moedas.add(moeda);
    }

    public void removerMoeda(Moeda moeda) {
        this.moedas.remove(moeda);
    }

    public List<Moeda> getMoedas() {
        return this.moedas;
    }

    public void listarMoedas() {
        if (this.moedas.isEmpty()) {
            System.out.println("Não há moedas no cofre!");
        } else {
            System.out.println("Moedas no cofre:");
            for (Moeda m : this.moedas) {
                System.out.println(m.toString());
            }
        }
    }

    public double calcularTotalReal() {
        double total = 0;
        for (Moeda m : this.moedas) {
            if (m instanceof Real) {
                total += m.getValor();
            } else if (m instanceof Dolar) {
                total += m.getValor() * 5.71;
            } else if (m instanceof Euro) {
                total += m.getValor() * 6.71;
            }
        }
        return total;
    }
}
