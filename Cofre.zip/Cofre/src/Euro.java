public class Euro extends Moeda {

    public Euro(double valor, String pais) {
        super(valor, "EUR", pais);
    }

    // método toString() para retornar uma representação em String da moeda
    @Override
    public String toString() {
        return String.format("€ %.2f", this.getValor());
    }
}
