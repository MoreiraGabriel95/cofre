import java.util.Scanner;
/*/As classes estão dispostas como pedido*/

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cofre cofre = new Cofre();
        int opcao = 0;
        do {
            System.out.println("Selecione uma opção:");
            System.out.println("1 - Adicionar moeda");
            System.out.println("2 - Remover moeda");
            System.out.println("3 - Listar moedas");
            System.out.println("4 - Calcular total em Real");
            System.out.println("0 - Sair");
            opcao = scanner.nextInt();
            switch (opcao) {
            case 1:
                System.out.println("Digite o valor da moeda:");
                double valor = scanner.nextDouble();
                System.out.println("Digite o país da moeda:");
                String pais = scanner.next();
                System.out.println("Selecione o tipo de moeda:");
                System.out.println("1 - Dolar");
                System.out.println("2 - Euro");
                System.out.println("3 - Real");
                int tipoMoeda = scanner.nextInt();
                Moeda moeda = null;
                switch (tipoMoeda) {
                    case 1:
                        moeda = new Dolar(valor, pais);
                        break;
                    case 2:
                        moeda = new Euro(valor, pais);
                        break;
                    case 3:
                        moeda = new Real(valor, pais);
                        break;
                    default:
                        System.out.println("Opção inválida!");
                        break;
                }
                if (moeda != null) {
                    cofre.adicionarMoeda(moeda);
                    System.out.println("Moeda adicionada com sucesso!");
                }
                break;
            case 2:
                System.out.println("Digite o valor da moeda a ser removida:");
                double valorRemover = scanner.nextDouble();
                System.out.println("Digite o país da moeda a ser removida:");
                String paisRemover = scanner.next();
                Moeda moedaRemover = null;
                for (Moeda m : cofre.getMoedas()) {
                    if (m.getValor() == valorRemover && m.getPais().equals(paisRemover)) {
                        moedaRemover = m;
                        break;
                    }
                }
                if (moedaRemover != null) {
                    cofre.removerMoeda(moedaRemover);
                    System.out.println("Moeda removida com sucesso!");
                } else {
                    System.out.println("Moeda não encontrada!");
                }
                break;
            case 3:
                cofre.listarMoedas();
                break;
            case 4:
                double totalReal = cofre.calcularTotalReal();
                System.out.println("Total em Real: R$" + totalReal);
                break;
            case 0:
                System.out.println("Saindo...");
                break;
            default:
                System.out.println("Opção inválida!");
                break;
            }
        } while (opcao != 0);
    }
}
