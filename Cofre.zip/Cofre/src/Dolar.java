public class Dolar extends Moeda {

    public Dolar(double valor, String pais) {
        super(valor, "USD", pais);
    }

    // método toString() para retornar uma representação em String da moeda
    @Override
    public String toString() {
        return String.format("$ %.2f", this.getValor());
    }
}
